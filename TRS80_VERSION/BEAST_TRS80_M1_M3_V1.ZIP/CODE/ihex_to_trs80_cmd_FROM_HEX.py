# ihex_to_trs80_cmd.py
# Convert Intel HEX to TRS-80 Model I/III TRSDOS /CMD executable.
#
# Usage:
#   python ihex_to_trs80_cmd.py BEAST-TRS80.HEX BEAST.CMD BEAST 5200

import sys

def parse_ihex(path):
    mem = {}
    base = 0
    with open(path, "r", encoding="ascii", errors="strict") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if not line.startswith(":"):
                raise ValueError("Bad HEX line: " + line)

            n = int(line[1:3], 16)
            addr = int(line[3:7], 16)
            rectype = int(line[7:9], 16)
            data = bytes.fromhex(line[9:9 + n * 2])
            raw = bytes.fromhex(line[1:9 + n * 2 + 2])
            if sum(raw) & 0xFF:
                raise ValueError("Bad HEX checksum: " + line)

            if rectype == 0x00:
                full = base + addr
                for i, b in enumerate(data):
                    mem[full + i] = b
            elif rectype == 0x01:
                break
            elif rectype == 0x04:
                base = int.from_bytes(data, "big") << 16
            elif rectype == 0x02:
                base = int.from_bytes(data, "big") << 4

    if not mem:
        raise ValueError("No data records found")

    start = min(mem)
    end = max(mem)
    image = bytes(mem.get(a, 0) for a in range(start, end + 1))
    return start, end, image

def cmd_len_byte(payload_len):
    # TRS-80 /CMD type-1 special cases:
    # len 0 => 256 payload bytes, len 1 => 257, len 2 => 258.
    if payload_len == 256:
        return 0
    if payload_len == 257:
        return 1
    if payload_len == 258:
        return 2
    if not (0 <= payload_len <= 255):
        raise ValueError(f"CMD payload too large: {payload_len}")
    return payload_len

def make_cmd(start, image, name, entry, chunk_size=128):
    name = name.upper()[:6].ljust(6)
    out = bytearray()

    # Optional filename/header record.
    out += bytes([0x05, 0x06]) + name.encode("ascii")

    pos = 0
    while pos < len(image):
        chunk = image[pos:pos + chunk_size]
        addr = start + pos
        payload = bytes([addr & 0xFF, (addr >> 8) & 0xFF]) + chunk
        out += bytes([0x01, cmd_len_byte(len(payload))]) + payload
        pos += len(chunk)

    out += bytes([0x02, 0x02, entry & 0xFF, (entry >> 8) & 0xFF])
    return out

def main():
    if len(sys.argv) != 5:
        print("Usage: python ihex_to_trs80_cmd.py input.hex output.cmd NAME entry_hex")
        sys.exit(1)

    in_hex, out_cmd, name, entry_hex = sys.argv[1:]
    start, end, image = parse_ihex(in_hex)
    entry = int(entry_hex, 16)

    cmd = make_cmd(start, image, name, entry)

    with open(out_cmd, "wb") as f:
        f.write(cmd)

    print(f"Load address: {start:04X}")
    print(f"End address:  {end:04X}")
    print(f"Entry point:  {entry:04X}")
    print(f"Binary bytes: {len(image)}")
    print(f"CMD bytes:    {len(cmd)}")
    print(f"Wrote:        {out_cmd}")

if __name__ == "__main__":
    main()
